<div class="sidebar"><br>
<h3 class="text">Dashboard</h3><br><hr><br>
<ul class="s">
<?php
	if(isset($_SESSION["AID"]))
	{
		echo'
			<li class="li"><a href="admin_home.php">Student Database Information</a></li>
			<li class="li"><a href="add_class.php"> Semester</a></li>
			<li class="li"><a href="add_sub.php"> Subject</a></li>

			<li class="li"><a href="add_staff.php"> Add Staff</a></li>
			<li class="li"><a href="view_staff.php">View Staff</a></li>
			<li class="li"><a href="set_exam.php"> Set Exam</a></li>
			<li class="li"><a href="view_exam.php"> View Exam</a></li>
			<li class="li"><a href="student.php"target="_blank"> View Students</a></li>
			<li class="li"><a href="view_student.php"target="_blank"> View Student</a></li>
			<li class="li"><a href="view_failures.php"> View Failures</a></li>
			<li class="li"><a href="view_distinctions.php"> View Distinctions</a></li>
			<li class="li"><a href="view_marks_admin.php"> View Result</a></li>
			<li class="li"><a href="results.php"target="_blank">Results Section wise</a></li>
			<li class="li"><a href="bar.php"target="_blank">Reports on average marks of all</a></li>
			<li class="li"><a href="reports.php"target="_blank"> Average marks based on Semester </a></li>
			
			<li class="li"><a href="logout.php">Logout</a></li>
		
		';
	
	
	}
	else{
		echo'
			<li class="li"><a href="teacher_home.php"> Profile</a></li>
			<li class="li"><a href="handle_class.php"> Handled Class</a></li>
			<li class="li"><a href="add_stud.php"> Add Students</a></li>
			<li class="li"><a href="view_stud_teach.php" target="_blank"> View Student</a></li>

			<li class="li"><a href="tech_view_exam.php"> View Exam</a></li>
			<li class="li"><a href="add_mark.php"> Add Marks</a></li>
			<li class="li"><a href="view_mark.php"> View Result</a></li>
			<li class="li"><a href="logout.php">Logout</a></li>

		
		';
	}


?>
	

</ul>

</div>