<?php
	include"database.php";
	session_start();
	if(!isset($_SESSION["AID"]))
	{
		echo"<script>window.open('index.php?mes=Access Denied..','_self');</script>";
		
	}		
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Admin Homepage</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
	
		<?php include"navbar.php";?>
		
		
		<img src="img/a.jpg" style="margin-left:0px;" width="100%" class="sha">
			
			<div id="section" style="margin-left:10px;">
			
				<?php include"sidebar.php";?><br>
			
				<div class="content">
					<h3 class="text">Welcome <?php echo $_SESSION["ANAME"]; ?></h3><br><hr><br>
						<h3 > SPAS</h3><br>
					<p class="para">
						Student Performance Analysis System is a complete Analysis System 
						software designed to automate a College's diverse operations from 
						classes, exams to college events calendar. 
					</p>
					
					<p class="para">
						This Analysis software has a powerful online community to bring 
						parents, faculties and students on a common interactive platform.
						It is a paperless office automation solution for today's modern
						Colleges. The Student Performance Analysis System provides the 
						facility to carry out all day to day activities of the College.
					</p>
				</div>
				
			</div>
	
		<?php include"footer.php";?>
	</body>
</html>