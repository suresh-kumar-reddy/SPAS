<?php
	$db=new mysqli("localhost","root","","spas");
	if(!$db)
	{
		echo "failed";
	}
	
?>